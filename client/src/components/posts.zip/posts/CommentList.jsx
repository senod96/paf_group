import React, { useEffect, useState } from "react";

const CommentList = ({ postId, show = true, onClose = () => {}, refreshTrigger = 0 }) => {
  const [comments, setComments] = useState([]);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const res = await fetch(`http://localhost:8080/api/comments/post/${postId}`);
        const data = await res.json();
        setComments(data);
      } catch (err) {
        console.error("Error fetching comments:", err);
      }
    };

    if (show) fetchComments();
  }, [postId, refreshTrigger, show]);

  if (!show) return null;

  return (
    <div className="mt-4 border border-gray-200 rounded-lg bg-white shadow-md p-4 font-sans relative">
      <button
        onClick={onClose}
        className="absolute top-2 right-3 text-gray-400 hover:text-gray-600 text-sm"
      >
        ✖
      </button>

      <h4 className="text-lg font-bold text-blue-700 mb-3">Comments</h4>

      {comments.length === 0 ? (
        <p className="text-sm text-gray-500">No comments yet.</p>
      ) : (
        <ul className="space-y-3">
          {comments.map((comment) => (
            <li
              key={comment.commentId}
              className="bg-gray-50 border rounded-md p-3 shadow-sm"
            >
              <div className="text-sm text-gray-800">{comment.comment}</div>
              <div className="text-xs text-gray-500 mt-1">❤️ {comment.likes}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default CommentList;
